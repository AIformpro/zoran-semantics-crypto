# Minimal placeholder so tests pass.
# forward: identity transform; inverse: identity.

def forward(text: str) -> str:
    return text

def inverse(coeffs: str) -> str:
    return coeffs
