# zoran-semantique-crypto

Prototype de cryptage sémantique (ondelettes sémantiques & qubits de sens).
> Remplacez ce README par celui de votre dépôt si déjà présent.

## Installation
```bash
pip install -e .
```

## CLI
```bash
zsc enc "bonjour zoran"
zsc dec "<payload_base64>"
```
