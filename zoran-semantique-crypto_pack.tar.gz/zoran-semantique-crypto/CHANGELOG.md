# Changelog

## 0.1.0
- Initial minimal, executable prototype.
- CLI: `zsc enc <text>` / `zsc dec <b64>`.
- Round-trip test ensures basic integrity.
