# Security Policy

- Report vulnerabilities privately via: security@institutia.example
- Please include reproduction steps and version info.
